import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginPage {

	public static WebDriver driver;

	public static void main(String[] args) throws Exception {

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.navigate().to("https://seprojcontactmanager.herokuapp.com/");

		// Login Code

		driver.findElement(By.xpath("//input[@id='id_username']")).sendKeys("Test_Login");
		driver.findElement(By.xpath("//input[@id='id_password']")).sendKeys("just_for_testing");
		driver.findElement(By.xpath("//input[@value='Login']")).click();

		// Add Contact

		driver.findElement(By.xpath("//a[@href='/contacts/create']")).click();
		driver.findElement(By.xpath("//input[@id='id_name']")).sendKeys("Test1");
		driver.findElement(By.xpath("//input[@id='id_email']")).sendKeys("Test123@gg.com");
		driver.findElement(By.xpath("//input[@id='id_phone']")).sendKeys("12121");
		driver.findElement(By.xpath("//input[@id='id_info']")).sendKeys("Automation Tester");

		Select s = new Select(driver.findElement(By.xpath("//select[@id='id_gender']")));
		s.selectByVisibleText("Female");

		driver.findElement(By.xpath("//input[@value='Create']")).click();
	}

}
